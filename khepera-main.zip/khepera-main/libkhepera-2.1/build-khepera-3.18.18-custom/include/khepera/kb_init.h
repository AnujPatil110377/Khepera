/*--------------------------------------------------------------------
 * kb_init.h - KoreBot Library -  Initialization
 *--------------------------------------------------------------------
 * $Id: kb_init.h,v 1.1 2004/07/29 10:51:55 cgaudin Exp $
 *--------------------------------------------------------------------
 * $Author: cgaudin $
 * $Revision: 1.1 $
 * $Date: 2004/07/29 10:51:55 $
 *--------------------------------------------------------------------*/

#ifndef __kb_init__
#define __kb_init__

extern int  kb_init( int argc , char * argv[] );
extern void kb_exit( void );

#endif /* __kb_init__ */
