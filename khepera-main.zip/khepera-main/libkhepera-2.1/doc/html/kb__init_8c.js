var kb__init_8c =
[
    [ "kb_exit", "kb__init_8c.html#aeb3ec73ea4f99817d924627a37f9944e", null ],
    [ "kb_init", "kb__init_8c.html#adf1ca4007100c026fae148afe3e4b6f2", null ],
    [ "kb_init_done", "kb__init_8c.html#afa9b46f59c016c9ef8581b6862b608aa", null ],
    [ "long_opts", "kb__init_8c.html#a16ad17a5d20ab00a011e4a58f1372333", null ],
    [ "short_opts", "kb__init_8c.html#a27a41ff2d90bb21238779c8b3a5bd715", null ]
];