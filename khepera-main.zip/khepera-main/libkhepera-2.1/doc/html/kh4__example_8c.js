var kh4__example_8c =
[
    [ "IR_BAR_LEN", "kh4__example_8c.html#a36b0e30a09cdb978bdda2434f135a9e5", null ],
    [ "MAX_US_DISTANCE", "kh4__example_8c.html#ae2b3e9b6f9a384478082c2c1dc973ea7", null ],
    [ "US_BAR_LEN", "kh4__example_8c.html#a2da76faf5c6d1a1bde9f7d68adc3bc66", null ],
    [ "US_VAL", "kh4__example_8c.html#a6bbbd6c3bb7f9231012bd381a2481a6c", null ],
    [ "ctrlc_handler", "kh4__example_8c.html#ac9f02fb0114292a308e093f0d9f8aa30", null ],
    [ "main", "kh4__example_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "dsPic", "kh4__example_8c.html#ab6f899a116b8a0c5179cd0f0cef9c4d6", null ],
    [ "quitReq", "kh4__example_8c.html#a7afd688646baddcb54287c2eec6949a9", null ]
];