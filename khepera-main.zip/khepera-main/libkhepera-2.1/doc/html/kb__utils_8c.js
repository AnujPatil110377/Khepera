var kb__utils_8c =
[
    [ "kb_change_term_mode", "kb__utils_8c.html#ae0f74bdc3e39c22863824c27207111c6", null ],
    [ "kb_clrscr", "kb__utils_8c.html#a889360304902149fb781081feb9e6599", null ],
    [ "kb_erase_line", "kb__utils_8c.html#ad43be20f9d7480e3c8fa5b1b04b37e87", null ],
    [ "kb_kbhit", "kb__utils_8c.html#a6d4fad179926dc14447c330a94e340ba", null ],
    [ "kb_move_cursor", "kb__utils_8c.html#aba2bbb231ebdc5c032b81852d9bd4006", null ],
    [ "kb_move_cursor_column", "kb__utils_8c.html#a7eb8907372cf9e87ad8ad5d16027748f", null ],
    [ "kb_move_cursor_line", "kb__utils_8c.html#a3c29a0f80d16e5e2ac086bb1259665dc", null ]
];