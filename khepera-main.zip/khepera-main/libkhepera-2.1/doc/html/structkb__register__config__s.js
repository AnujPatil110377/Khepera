var structkb__register__config__s =
[
    [ "next", "structkb__register__config__s.html#aa2df5fde41f6774ce3bf69a903c9d3cb", null ],
    [ "value", "structkb__register__config__s.html#af771e749c2b5d2abbec033294038cf29", null ]
];