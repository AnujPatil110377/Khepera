var struct__fifo =
[
    [ "head", "struct__fifo.html#a4a130f4fdfcd918d68279cfa921f8b45", null ],
    [ "length", "struct__fifo.html#a79fd3045e759daf3cb1c4cce1e98d8d2", null ],
    [ "mutex", "struct__fifo.html#a1ec3b1ebafcc3add7584f0db65787c8f", null ],
    [ "queue", "struct__fifo.html#a54746fa451ff2e093aa27170453212e0", null ]
];