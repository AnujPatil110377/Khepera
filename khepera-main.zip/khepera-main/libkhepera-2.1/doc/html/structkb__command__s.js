var structkb__command__s =
[
    [ "maxParam", "structkb__command__s.html#a38f03d18706aa194a75c85d53bdcc47c", null ],
    [ "minParam", "structkb__command__s.html#aaca466330e5d2f7d346d834372e79e8d", null ],
    [ "name", "structkb__command__s.html#a75591e4df142e619f2c3eb3983445bd2", null ],
    [ "parse", "structkb__command__s.html#aaf7e62c9727b58395c666a3a8880d8a3", null ]
];