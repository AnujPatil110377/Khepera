var structknet__rs232__s =
[
    [ "fd", "structknet__rs232__s.html#a212a0e13478cb014a0c1fe782d09aaca", null ],
    [ "tios", "structknet__rs232__s.html#a8239c8d98cf06ca3f231cae021c48594", null ]
];