var klrf__small__ex_8c =
[
    [ "LRF_DEVICE", "klrf__small__ex_8c.html#a55e572b0d5166ed71ac4c8c7fe966c52", null ],
    [ "main", "klrf__small__ex_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ]
];