var kb__memory_8c =
[
    [ "kb_alloc", "kb__memory_8c.html#abe1cf0dffd093ca034d94486c5366872", null ],
    [ "kb_realloc", "kb__memory_8c.html#add347b03be926d914253f46f80e01765", null ]
];