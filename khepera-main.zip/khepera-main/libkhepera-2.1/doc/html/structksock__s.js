var structksock__s =
[
    [ "serv_addr", "structksock__s.html#ac7e95cef134ae6c943e2832b82eb8447", null ],
    [ "serv_socket", "structksock__s.html#a0e9bd44debe730281053a685b3f62e3c", null ]
];