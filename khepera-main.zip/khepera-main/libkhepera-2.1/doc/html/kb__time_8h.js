var kb__time_8h =
[
    [ "kb_time_t", "kb__time_8h.html#a89a869b8afe504e5eb729a0ab1e1738f", null ],
    [ "kb_getTime", "kb__time_8h.html#a1d96883ed49195c36ef5740dcce2f590", null ]
];