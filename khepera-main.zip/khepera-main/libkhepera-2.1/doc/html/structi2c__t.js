var structi2c__t =
[
    [ "dev", "structi2c__t.html#ab7cbeb66e965d856b5133c7f998cdafa", null ],
    [ "fd", "structi2c__t.html#ad2d052aed2c40e693d1687a16cd12c69", null ]
];