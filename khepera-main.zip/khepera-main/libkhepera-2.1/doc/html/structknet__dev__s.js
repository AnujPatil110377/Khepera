var structknet__dev__s =
[
    [ "bus", "structknet__dev__s.html#af39fe352705cd67e1eee9c7b233ab5b5", null ],
    [ "ext_addr", "structknet__dev__s.html#a5f7ced417fe734d43e8974cae2f7d29a", null ],
    [ "info", "structknet__dev__s.html#a6ddea71c87f99ebc0e32523f13f135db", null ],
    [ "mod_addr", "structknet__dev__s.html#a6ab702f7b706076f0ec6d155a0813ace", null ],
    [ "name", "structknet__dev__s.html#a62fd6afe866aa2d924760843d19b6a35", null ],
    [ "next", "structknet__dev__s.html#a4e187409e9203fd40546ec0512ccfe75", null ],
    [ "order", "structknet__dev__s.html#ab2685d41e43c700958fb457fd3567989", null ],
    [ "usage_counter", "structknet__dev__s.html#a90eaeac624c3a5d73fd7b3b1b0501155", null ]
];