var structkb__device__config__s =
[
    [ "address", "structkb__device__config__s.html#a6035b2ca4752bb88278400ae7847643d", null ],
    [ "defined", "structkb__device__config__s.html#ab2a6bd56a77a9f83760694cc8fdeeb87", null ],
    [ "device_name", "structkb__device__config__s.html#a9f9e5e74e5ef1b33b88a7493d8d672c0", null ],
    [ "kclass", "structkb__device__config__s.html#a20134f03f8835e5b0a87d8cc6482f1d5", null ],
    [ "next", "structkb__device__config__s.html#a4608d7111d634ececa32bc51babf5036", null ],
    [ "section", "structkb__device__config__s.html#aa655e7cba5ca44bc2fbe1efef4d928d3", null ]
];