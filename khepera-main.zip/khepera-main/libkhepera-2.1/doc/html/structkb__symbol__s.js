var structkb__symbol__s =
[
    [ "alloc", "structkb__symbol__s.html#a01270355937521e5074657be24a37a8d", null ],
    [ "name", "structkb__symbol__s.html#a1734aaf646b77824fab975472af69be1", null ],
    [ "next", "structkb__symbol__s.html#ad5f81fe8e1f188888c904ace6dd4a086", null ],
    [ "type", "structkb__symbol__s.html#a0f2ab8ebb5fb565c551ecaffbd626ebb", null ],
    [ "value", "structkb__symbol__s.html#a985c7a060f626ea4eda0c5dad5a15f9d", null ]
];