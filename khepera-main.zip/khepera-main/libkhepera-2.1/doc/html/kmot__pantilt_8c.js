var kmot__pantilt_8c =
[
    [ "MARGIN", "kmot__pantilt_8c.html#ab05a798afd72aac947f417e1dab73c87", null ],
    [ "TGT_MARGIN", "kmot__pantilt_8c.html#a49313136584e74f6f04087791b3c841b", null ],
    [ "InitMotor", "kmot__pantilt_8c.html#a3739a1980a596aeb1a6f0bbf5cdc5221", null ],
    [ "main", "kmot__pantilt_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "PantiltOpen", "kmot__pantilt_8c.html#a962e17d7afb131256c9b76e5f49fa74c", null ]
];