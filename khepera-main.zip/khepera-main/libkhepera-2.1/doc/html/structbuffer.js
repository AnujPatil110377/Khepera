var structbuffer =
[
    [ "length", "structbuffer.html#a4f467cc251f2f4504d484913c7da47bd", null ],
    [ "start", "structbuffer.html#a8be3721dc0863d9dd7460504bbaeb0d1", null ]
];