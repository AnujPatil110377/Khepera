var kb__time_8c =
[
    [ "kb_getTime", "kb__time_8c.html#a1d96883ed49195c36ef5740dcce2f590", null ],
    [ "ref_time", "kb__time_8c.html#a97a9bf839ae78b58ced60e155362345d", null ]
];