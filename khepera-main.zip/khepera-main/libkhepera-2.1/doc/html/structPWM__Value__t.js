var structPWM__Value__t =
[
    [ "duty", "structPWM__Value__t.html#aaa14098b6504bce268d0737cfb389dcb", null ],
    [ "frequency", "structPWM__Value__t.html#aa072d5526dc1eac8a1df1ee2a1ea49bc", null ],
    [ "pwm", "structPWM__Value__t.html#afcb50ec1066ec0575fbb97cf2315e065", null ]
];