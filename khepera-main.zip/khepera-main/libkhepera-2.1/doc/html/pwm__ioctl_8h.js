var pwm__ioctl_8h =
[
    [ "PWM_IOC_MAGIC", "pwm__ioctl_8h.html#a5899b5088eae3b25e9bd240285097af2", null ],
    [ "PWM_IOC_MAXNR", "pwm__ioctl_8h.html#ad30e5810ab12e4dddf97447e85509e75", null ],
    [ "PWM_PULSE_RESET", "pwm__ioctl_8h.html#afc08ce31b585c482e5026202004684e6", null ],
    [ "PWM_PULSE_SET", "pwm__ioctl_8h.html#a6626d7f75099e39bc5d4de020afd267e", null ]
];