var koreioLE__auto_8c =
[
    [ "ctrlc_handler", "koreioLE__auto_8c.html#ac9f02fb0114292a308e093f0d9f8aa30", null ],
    [ "help", "koreioLE__auto_8c.html#ae3d6a45deeef910eb59d5be977b0dfa1", null ],
    [ "main", "koreioLE__auto_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "quit", "koreioLE__auto_8c.html#ae92fb5ec62807efb0ce1b2171784066f", null ],
    [ "readios", "koreioLE__auto_8c.html#ad888ddb9d725372c4849b3efa9b20db0", null ],
    [ "buf", "koreioLE__auto_8c.html#ac75fce8692fd1d41a8985f6aacc4a175", null ],
    [ "cmds", "koreioLE__auto_8c.html#a5532197815d495c65c2c74f6cd107825", null ],
    [ "koreio", "koreioLE__auto_8c.html#aa25dd9f9732a5e84db9ba8d7b1f86052", null ],
    [ "quitReq", "koreioLE__auto_8c.html#a7afd688646baddcb54287c2eec6949a9", null ]
];