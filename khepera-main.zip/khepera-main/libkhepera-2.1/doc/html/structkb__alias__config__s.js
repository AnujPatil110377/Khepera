var structkb__alias__config__s =
[
    [ "name", "structkb__alias__config__s.html#a2bc67b7e83fa778f2ebd7bd075bbe334", null ],
    [ "next", "structkb__alias__config__s.html#afc1ece0b2115ea3b5bc3af43a19255c8", null ],
    [ "ptr", "structkb__alias__config__s.html#acbff3d272f20c6222d3599a95b156242", null ]
];