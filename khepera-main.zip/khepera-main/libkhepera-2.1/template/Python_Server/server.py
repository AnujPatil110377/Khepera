import socket
import time

# Server settings
UDP_IP_ADDRESS = "192.168.0.108"  # Replace with your server IP address
UDP_PORT_NO = 3000
serverSock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
serverSock.bind((UDP_IP_ADDRESS, UDP_PORT_NO))

def parse_sensor_data(data):
    # Example parser for sensor data
    sensors = {}
    sensors['acc_X'] = float(data.split('AX')[1].split('AX')[0])
    sensors['acc_Y'] = float(data.split('AY')[1].split('AY')[0])
    sensors['acc_Z'] = float(data.split('AZ')[1].split('AZ')[0])
    return sensors

def move_robot_forward_by_distance(addr, distance, speed):
    """
    Send command to move the robot forward by a specific distance.

    :param addr: Address tuple (IP, port) of the robot
    :param distance: Distance to move forward (in meters)
    :param speed: Speed at which to move (in meters per second)
    """
    # Calculate the duration to move the specified distance at the given speed
    duration = distance / speed

    # Command format: "WxV"
    command = f"0x{1.0}".encode()

    # Send the move command
    serverSock.sendto(command, addr)

    # Wait for the duration to move the specified distance
    time.sleep(duration)

    # Stop the robot
    stop_command = "0x0".encode()
    serverSock.sendto(stop_command, addr)

while True:
    data, addr = serverSock.recvfrom(1024)  # buffer size is 1024 bytes
    print("Message received from:", addr)

    # Parse the data
    parsed_data = parse_sensor_data(data.decode())
    print("Parsed Data:", parsed_data)

    # Example: Move robot forward by 1 meter at 0.2 meters/second
    move_robot_forward_by_distance(addr, 1, 0.2)
