#include <khepera/khepera.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

static knet_dev_t *dsPic; // Robot PIC microcontroller

int main(int argc, char *argv[]) {
    int socket_desc, client_sock, c, read_size;
    struct sockaddr_in server, client;
    char client_msg[2000];

    // Create socket
    socket_desc = socket(AF_INET, SOCK_STREAM, 0);
    if (socket_desc == -1) {
        printf("Could not create socket\n");
    }
    puts("Socket created");

    // Prepare the sockaddr_in structure
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(8080);

    // Bind
    if (bind(socket_desc, (struct sockaddr *)&server, sizeof(server)) < 0) {
        perror("Bind failed. Error");
        return 1;
    }
    puts("Bind done");

    // Listen
    listen(socket_desc, 3);

    // Accept an incoming connection
    puts("Waiting for incoming connections...");
    c = sizeof(struct sockaddr_in);
    client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t*)&c);
    if (client_sock < 0) {
        perror("Accept failed");
        return 1;
    }
    puts("Connection accepted");

    // Initialize the robot
    if (kh4_init(argc, argv) != 0) {
        printf("Error while initializing the Khepera IV robot\n");
        return 1;
    }

    dsPic = knet_open("Khepera4:dsPic", KNET_BUS_I2C, 0, NULL);
    if (dsPic == NULL) {
        printf("Cannot open robot socket\n");
        return 1;
    }

    // Set the motor speed mode
    kh4_SetMode(kh4RegSpeedProfile, dsPic);

    // Receive messages from client
    while ((read_size = recv(client_sock, client_msg, 2000, 0)) > 0) {
        // Parse the message for left and right velocities
        int vLeft = client_msg[0] - '0';
        int vRight = client_msg[1] - '0';
        printf("Received velocities: Left %d, Right %d\n", vLeft, vRight);

        // Set motor speeds
        kh4_set_speed(vLeft * 10, vRight * 10, dsPic);
    }

    if (read_size == 0) {
        puts("Client disconnected");
        fflush(stdout);
    } else if (read_size == -1) {
        perror("Receive failed");
    }

    // Close connection and clean up
    close(client_sock);
    close(socket_desc);
    kh4_set_speed(0, 0, dsPic); // Stop the robot
    kh4_free();

    return 0;
}
